echo -e "small-test-dataset.txt\nno\n3 5 7" | python main.py > trace.txt
echo -e "large-test-dataset.txt\nno\n1 15 27" | python main.py > trace-long.txt